import Employee from "../models/Employee.js";
import Country from "../models/Country.js";
import State from "../models/State.js";
import City from "../models/City.js";
import Area from "../models/Area.js";
import Service from "../models/Service.js";
import Activity from "../models/Activity.js";

export const searchEmployees = async (req, res) => {
    try {
        const { countryName, stateName, cityName, areaName } = req.query;
        const filter = {};

        if (countryName) {
            const country = await Country.findOne({ countryName: { $regex: `^${countryName}$`, $options: "i" } });
            if (!country) return res.status(404).json({ message: "Country not found" });
            filter.countryId = country.countryId;
        }

        if (stateName) {
            const state = await State.findOne({ stateName: { $regex: `^${stateName}$`, $options: "i" } });
            if (!state) return res.status(404).json({ message: "State not found" });
            filter.stateId = state.stateId;
        }

        if (cityName) {
            const city = await City.findOne({ cityName: { $regex: `^${cityName}$`, $options: "i" } });
            if (!city) return res.status(404).json({ message: "City not found" });
            filter.cityId = city.cityId;
        }

        if (areaName) {
            const area = await Area.findOne({ areaName: { $regex: `^${areaName}$`, $options: "i" } });
            if (!area) return res.status(404).json({ message: "Area not found" });
            filter.areaId = area.areaId;
        }

        const employees = await Employee.aggregate([
            { $match: filter },
            { $lookup: { from: "countries", localField: "countryId", foreignField: "countryId", as: "country" } },
            { $unwind: "$country" },
            { $lookup: { from: "states", localField: "stateId", foreignField: "stateId", as: "state" } },
            { $unwind: "$state" },
            { $lookup: { from: "cities", localField: "cityId", foreignField: "cityId", as: "city" } },
            { $unwind: "$city" },
            { $lookup: { from: "areas", localField: "areaId", foreignField: "areaId", as: "area" } },
            { $unwind: "$area" },
            {
                $project: {
                    _id: 1,
                    empId: 1,
                    empName: 1,
                    email: 1,
                    phone: 1,
                    address: 1,
                    joinDate: 1,
                    bio: 1,
                    role: 1,
                    avatar: 1,
                    specialties: 1,
                    certifications: 1,
                    rating: 1,
                    completedJobs: 1,
                    settings: 1,
                    statistics: 1,
                    "country.countryName": 1,
                    "state.stateName": 1,
                    "city.cityName": 1,
                    "area.areaName": 1
                }
            }
        ]);

        res.json(employees);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Get employee profile by ID
export const getEmployeeProfile = async (req, res) => {
    try {
        const { id } = req.params;
        
        const employee = await Employee.findOne({ empId: parseInt(id) });
        if (!employee) {
            return res.status(404).json({ message: "Employee not found" });
        }

        res.json(employee);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Get employee dashboard data
export const getEmployeeDashboard = async (req, res) => {
    try {
        const { id } = req.params;
        const empId = parseInt(id);

        const [employee, assignedServices, completedServices, recentActivities] = await Promise.all([
            Employee.findOne({ empId }),
            Service.find({ empId, status: 'assigned' }).sort({ scheduledDate: 1 }),
            Service.find({ empId, status: 'completed' }).sort({ completedDate: -1 }),
            Activity.find({ empId }).sort({ createdAt: -1 }).limit(10)
        ]);

        if (!employee) {
            return res.status(404).json({ message: "Employee not found" });
        }

        // Calculate statistics
        const totalEarnings = completedServices.reduce((sum, service) => sum + service.payment, 0);
        const totalHours = completedServices.reduce((sum, service) => sum + (service.actualHours || service.estimatedHours), 0);
        
        // Update employee statistics
        employee.statistics.totalEarnings = totalEarnings;
        employee.statistics.hoursWorked = totalHours;
        await employee.save();

        res.json({
            employee,
            assignedServices,
            completedServices,
            recentActivities,
            statistics: employee.statistics
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Update employee profile
export const updateEmployeeProfile = async (req, res) => {
    try {
        const { id } = req.params;
        const updateData = req.body;

        const employee = await Employee.findOneAndUpdate(
            { empId: parseInt(id) },
            updateData,
            { new: true, runValidators: true }
        );

        if (!employee) {
            return res.status(404).json({ message: "Employee not found" });
        }

        // Log activity
        await Activity.create({
            empId: parseInt(id),
            type: 'profile_updated',
            message: 'Profile information updated'
        });

        res.json(employee);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

// Update employee settings
export const updateEmployeeSettings = async (req, res) => {
    try {
        const { id } = req.params;
        const settings = req.body;

        const employee = await Employee.findOneAndUpdate(
            { empId: parseInt(id) },
            { settings },
            { new: true }
        );

        if (!employee) {
            return res.status(404).json({ message: "Employee not found" });
        }

        res.json(employee.settings);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

// Get employee activities
export const getEmployeeActivities = async (req, res) => {
    try {
        const { id } = req.params;
        const activities = await Activity.find({ empId: parseInt(id) })
            .sort({ createdAt: -1 })
            .limit(20);

        res.json(activities);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};