import mongoose from "mongoose";

const employeeSchema = new mongoose.Schema({
    empId: { type: Number, unique: true },
    empName: String,
    email: String,
    countryId: Number,
    stateId: Number,
    cityId: Number,
    areaId: Number,
    // New fields for profile system
    phone: String,
    address: String,
    joinDate: { type: Date, default: Date.now },
    bio: String,
    role: { type: String, default: "Service Technician" },
    avatar: { type: String, default: "DP" },
    specialties: [String],
    certifications: [String],
    rating: { type: Number, default: 0 },
    completedJobs: { type: Number, default: 0 },
    settings: {
        emailNotifications: { type: Boolean, default: true },
        smsNotifications: { type: Boolean, default: true },
        pushNotifications: { type: Boolean, default: false },
        autoSchedule: { type: Boolean, default: true },
        shareLocation: { type: Boolean, default: true },
        showEarnings: { type: Boolean, default: true }
    },
    statistics: {
        totalEarnings: { type: Number, default: 0 },
        hoursWorked: { type: Number, default: 0 },
        avgRating: { type: Number, default: 0 },
        responseRate: { type: Number, default: 98 },
        completionRate: { type: Number, default: 99 },
        repeatCustomers: { type: Number, default: 45 }
    }
});

export default mongoose.model("Employee", employeeSchema);