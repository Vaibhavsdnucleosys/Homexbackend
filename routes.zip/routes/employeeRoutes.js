import express from "express";
import { 
    searchEmployees, 
    getEmployeeProfile, 
    getEmployeeDashboard, 
    updateEmployeeProfile, 
    updateEmployeeSettings, 
    getEmployeeActivities 
} from "../controllers/employeeController.js";

const router = express.Router();

router.get("/search", searchEmployees);
router.get("/:id", getEmployeeProfile);
router.get("/:id/dashboard", getEmployeeDashboard);
router.put("/:id", updateEmployeeProfile);
router.patch("/:id/settings", updateEmployeeSettings);
router.get("/:id/activities", getEmployeeActivities);

export default router;